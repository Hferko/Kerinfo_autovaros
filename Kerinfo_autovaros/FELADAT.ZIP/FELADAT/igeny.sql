-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Máj 17. 21:13
-- Kiszolgáló verziója: 10.4.14-MariaDB
-- PHP verzió: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `autovaros`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `igeny`
--

CREATE TABLE `igeny` (
  `marka` varchar(7) DEFAULT NULL,
  `szin` varchar(10) DEFAULT NULL,
  `kod` varchar(6) DEFAULT NULL,
  `id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `igeny`
--

INSERT INTO `igeny` (`marka`, `szin`, `kod`, `id`) VALUES
('audi', 'sarga', 'qa567b', ''),
('bmw', 'fekete', 'qb525b', ''),
('bmw', 'fekete', 'qb555c', ''),
('ford', 'piros', 'qf182b', ''),
('bmw', 'fekete', 'qb567b', ''),
('audi', 'feher', 'qa567b', ''),
('porsche', 'piros', 'qp911a', ''),
('fiat', 'kek', 'qfgg23', ''),
('ford', 'fekete', 'qf182c', ''),
('fiat', 'piros', 'qfgg23', ''),
('vw', 'zold', 'qv851b', ''),
('audi', 'szurke', 'qa567b', ''),
('audi', 'feher', 'qa567b', ''),
('porsche', 'piros', 'qp921a', ''),
('fiat', 'zold', 'qfgq33', ''),
('volvo', 'vilagoskek', 'qvs60f', ''),
('citroen', 'bordo', 'qr19rb', ''),
('porsche', 'flipflop', 'qp911a', ''),
('peugeot', 'feher', 'qpr118', ''),
('audi', 'arany', 'qa567b', ''),
('renault', 'turkiz', 'qr19rr', ''),
('volvo', 'vilagoskek', 'qvs60f', ''),
('vw', 'kek', 'qv851b', ''),
('vw', 'sarga', 'qv851b', ''),
('audi', 'zold', 'qa567b', ''),
('bmw', 'fekete', 'qb556b', ''),
('fiat', 'szurke', 'qfgg23', ''),
('fiat', 'feher', 'qfgg23', ''),
('porsche', 'feher', 'qp911a', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
