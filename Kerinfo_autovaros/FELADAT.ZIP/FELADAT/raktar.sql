-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Máj 17. 21:12
-- Kiszolgáló verziója: 10.4.14-MariaDB
-- PHP verzió: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `autovaros`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `raktar`
--

CREATE TABLE `raktar` (
  `marka` varchar(10) DEFAULT NULL,
  `szin` varchar(10) DEFAULT NULL,
  `kod` varchar(6) DEFAULT NULL,
  `id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `raktar`
--

INSERT INTO `raktar` (`marka`, `szin`, `kod`, `id`) VALUES
('ford', 'piros', 'qf182a', 1),
('ford', 'piros', 'qf182b', 2),
('vw', 'piros', 'qv851b', 3),
('vw', 'kek', 'qv851b', 4),
('fiat', 'feher', 'qfgg12', 5),
('fiat', 'zold', 'qfgg12', 6),
('audi', 'sarga', 'qa567b', 7),
('bmw', 'fekete', 'qb555b', 8),
('bmw', 'fekete', 'qb555c', 9),
('ford', 'piros', 'qf182b', 10),
('bmw', 'fekete', 'qb567b', 11),
('audi', 'feher', 'qa567b', 12),
('porsche', 'piros', 'qp911a', 13),
('fiat', 'kek', 'qfgg23', 14),
('ford', 'piros', 'qf182c', 15),
('fiat', 'feher', 'qfgg23', 16),
('vw', 'kek', 'qv851b', 17),
('audi', 'feher', 'qa567b', 18),
('bmw', 'fekete', 'qb556b', 19),
('porsche', 'piros', 'qp911a', 20),
('peugeot', 'szurke', 'qpe113', 21),
('peugeot', 'szurke', 'qpe113', 22),
('porsche', 'piros', 'qp911a', 23),
('mercedes', 'feher', 'qm221b', 24),
('mercedes', 'feher', 'qm221b', 25),
('audi', 'fekete', 'qa567b', 26),
('citroen', 'bordo', 'qr19rb', 27),
('audi', 'szurke', 'qa567b', 28),
('porsche', 'piros', 'qp911a', 29),
('peugeot', 'szurke', 'qpe118', 30),
('audi', 'feher', 'qa567b', 31),
('renault', 'arany', 'qr19rr', 32),
('nissan', 'zold', 'qn117s', 33),
('mitsubishi', 'rozsakvarc', 'qm235a', 34),
('porsche', 'sarga', 'qp911a', 35),
('porsche', 'sarga', 'qp911b', 36),
('ford', 'piros', 'qf182b', 37),
('peugeot', 'feher', 'qpe118', 38),
('vw', 'kek', 'qv851b', 39),
('peugeot', 'feher', 'qpe118', 40),
('audi', 'barna', 'qa567c', 41),
('ferrari', 'sarga', 'qf3551', 42),
('vw', 'kek', 'qv851b', 43),
('mercedes', 'feher', 'qm221a', 44),
('ford', 'piros', 'qf182b', 45),
('audi', 'barna', 'qa567c', 46),
('mitsubishi', 'rozsakvarc', 'qm235a', 47),
('citroen', 'bordo', 'qr19rb', 48),
('volvo', 'vilagoskek', 'qvs60f', 49),
('volvo', 'vilagoskek', 'qvs60f', 50);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
